package com.lemus.oscar.mascotas;

/**
 * Created by olemus on 26/05/2016.
 */
public class Mascota {
    private String nombre;
    private String rank;
    private int foto;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public Mascota(String nombre, String rank, int foto) {
        this.nombre = nombre;
        this.rank = rank;
        this.foto = foto;
    }
}
