package com.lemus.oscar.mascotas;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by olemus on 26/05/2016.
 */
public class MascotaAdaptador extends RecyclerView.Adapter<MascotaAdaptador.MascotaViewHolder> {

    ArrayList<Mascota> mascotas;
    Activity activity;

    public MascotaAdaptador(ArrayList<Mascota> mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
    }

    @Override
    public MascotaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_mascotas, parent, false);

        return new MascotaViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final MascotaViewHolder mascotaViewHolder, int position) {

        final Mascota mascota = mascotas.get(position);
        mascotaViewHolder.imgFoto.setImageResource(mascota.getFoto());
        mascotaViewHolder.tvNombreCv.setText(mascota.getNombre());
        mascotaViewHolder.tvNumRankCv.setText(mascota.getRank());
        mascotaViewHolder.btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mensaje = mascota.getNombre()  + " tenia " + mascota.getRank() + " y ahora tiene ";

                int rank = Integer.parseInt(mascota.getRank().toString()) + 1 ;

                mascotaViewHolder.tvNumRankCv.setText(String.valueOf(rank));

                mensaje = mensaje + String.valueOf(rank);
                Toast.makeText(activity, mensaje ,Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return mascotas.size();
    }

    public static class MascotaViewHolder extends RecyclerView.ViewHolder {

        private ImageView imgFoto;
        private TextView tvNombreCv;
        private TextView tvNumRankCv;
        private ImageButton btnLike;


        public MascotaViewHolder(View itemView) {
            super(itemView);

            imgFoto = (ImageView)itemView.findViewById(R.id.imgFotoMascota);
            tvNombreCv = (TextView)itemView.findViewById(R.id.tvNombreCv);
            tvNumRankCv = (TextView)itemView.findViewById(R.id.tvNumRankCv);
            btnLike = (ImageButton)itemView.findViewById(R.id.btnLike);

        }
    }

}
