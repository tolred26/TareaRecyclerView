package com.lemus.oscar.mascotas;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;

public class Ranking extends AppCompatActivity {

    ArrayList<Mascota> mascotas;
    private RecyclerView listMascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);

        if (getActionBar() != null) {
            getActionBar().setTitle(getResources().getString(R.string.app_name));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }


        android.support.v7.widget.Toolbar miActionBar = (android.support.v7.widget.Toolbar) findViewById(R.id.actionBar);
        setSupportActionBar(miActionBar);

        listMascotas = (RecyclerView)findViewById(R.id.rvMascotas);

        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listMascotas.setLayoutManager(llm);

        inicializarMascotas();
        inicializarAdaptador();
    }

    public void inicializarMascotas(){

        mascotas = new ArrayList<Mascota>();

        mascotas.add(new Mascota("elro", "5", R.drawable.sleeping_old_dog_icon));
        mascotas.add(new Mascota("el perro", "4", R.drawable.i_hate_cats_icon));
        mascotas.add(new Mascota("puppy", "2", R.drawable.dog_icon));
        mascotas.add(new Mascota("erro", "2", R.drawable.dog_icon_brown));
        mascotas.add(new Mascota("perro", "1", R.drawable.puppy_4_icon));
    }

    public MascotaAdaptador adaptador;
    public  void inicializarAdaptador(){
        adaptador = new MascotaAdaptador(mascotas, this);
        listMascotas.setAdapter(adaptador);
    }

    public void irDetalleMascota(View view) {
        Intent intent = new Intent(this, Ranking.class);
        startActivity(intent);

    }
}
